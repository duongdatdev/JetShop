package com.shoppy.shop.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)
val OffWhite = Color(0xFF19EED9)
val Transparent = Color(0x0)
val Orange= Color(0xFFFF5722)
val Custom = Color(0xFF000000)