package com.shoppy.shop.models

data class PushNotificationData(
    val data: NotificationData,
    val to: String,

)
